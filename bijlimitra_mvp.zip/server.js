const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");
const PUBLIC_DIR = path.join(__dirname, "public");
fs.mkdirSync(DATA_DIR, { recursive: true });

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-local-prototype-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));

const now = () => new Date().toISOString();
const id = (prefix) => `${prefix}_${crypto.randomUUID()}`;
const readDB = () => JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
const writeDB = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
const cleanUser = (u) => ({ id:u.id, username:u.username, role:u.role, name:u.name, housingType:u.housingType, apartment:u.apartment, block:u.block, flat:u.flat, locality:u.locality, street:u.street, houseNumber:u.houseNumber, landmark:u.landmark });

function incidentKey(user) {
  // Group primarily by apartment + block, or locality + street for independent homes.
  if (user.housingType === "apartment") return `apt:${(user.apartment||"").toLowerCase()}|${(user.block||"").toLowerCase()}`;
  return `home:${(user.locality||"").toLowerCase()}|${(user.street||"").toLowerCase()}`;
}
function seed() {
  if (fs.existsSync(DB_FILE)) return;
  const residents = [
    {username:"asha",password:"demo123",name:"Asha Rao",housingType:"apartment",apartment:"Green Valley Apartments",block:"A",flat:"101",locality:"Green Valley",street:"Lake Road",houseNumber:"",landmark:"Near lake"},
    {username:"rahul",password:"demo123",name:"Rahul Nair",housingType:"apartment",apartment:"Green Valley Apartments",block:"A",flat:"102",locality:"Green Valley",street:"Lake Road",houseNumber:"",landmark:"Near lake"},
    {username:"meera",password:"demo123",name:"Meera Shah",housingType:"independent",apartment:"",block:"",flat:"",locality:"Green Valley",street:"Lake Road",houseNumber:"18",landmark:"Near lake"},
    {username:"dev",password:"demo123",name:"Dev Kumar",housingType:"independent",apartment:"",block:"",flat:"",locality:"Green Valley",street:"Lake Road",houseNumber:"20",landmark:"Near lake"}
  ];
  const users = residents.map((r,i)=>({...r,id:id("usr"),role:"resident",createdAt:now(),passwordHash:bcrypt.hashSync(r.password,10)}));
  users.push({id:id("usr"),username:"admin",passwordHash:bcrypt.hashSync("admin123",10),role:"admin",name:"Locality Handler",createdAt:now()});
  writeDB({users, incidents:[], reports:[], notifications:[], statusUpdates:[], complaintLog:[]});
}
seed();

function requireAuth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"Please log in."}); next(); }
function currentUser(db,req){ return db.users.find(u=>u.id===req.session.userId); }
function notify(db,userId,title,message,incidentId){ db.notifications.push({id:id("ntf"),userId,title,message,incidentId:incidentId||null,read:false,createdAt:now()}); }
function notifyNeighbors(db, reporter, incident) {
  const key=incidentKey(reporter);
  db.users.filter(u=>u.role==="resident" && u.id!==reporter.id && incidentKey(u)===key)
    .forEach(u=>notify(db,u.id,"Power outage reported nearby",`${reporter.name} reported an outage in your area. Are you also affected?`,incident.id));
}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"BijliMitra local prototype"}));
app.post("/api/register",async(req,res)=>{
  const {username,password,name,housingType,apartment,block,flat,locality,street,houseNumber,landmark}=req.body||{};
  if(!username||!password||!name||!locality||!housingType||!["apartment","independent"].includes(housingType)) return res.status(400).json({error:"Enter username, password, name, housing type and locality."});
  if(housingType==="apartment" && (!apartment||!block||!flat)) return res.status(400).json({error:"Apartment residents must enter apartment, block and flat."});
  if(housingType==="independent" && (!street||!houseNumber)) return res.status(400).json({error:"Independent-house residents must enter street and house number."});
  const db=readDB();
  if(db.users.some(u=>u.username.toLowerCase()===String(username).toLowerCase())) return res.status(409).json({error:"Username already exists."});
  const user={id:id("usr"),username:String(username).trim(),passwordHash:await bcrypt.hash(password,10),role:"resident",name,housingType,apartment:apartment||"",block:block||"",flat:flat||"",locality,street:street||"",houseNumber:houseNumber||"",landmark:landmark||"",createdAt:now()};
  db.users.push(user); writeDB(db); req.session.userId=user.id;
  res.json({user:cleanUser(user)});
});
app.post("/api/login",async(req,res)=>{
  const {username,password}=req.body||{}; const db=readDB();
  const user=db.users.find(u=>u.username.toLowerCase()===String(username||"").toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.passwordHash))) return res.status(401).json({error:"Invalid username or password."});
  req.session.userId=user.id; res.json({user:cleanUser(user)});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",requireAuth,(req,res)=>{const db=readDB();const u=currentUser(db,req);res.json({user:cleanUser(u)});});

app.get("/api/dashboard",requireAuth,(req,res)=>{
  const db=readDB(), user=currentUser(db,req);
  const key=incidentKey(user);
  const active=db.incidents.filter(i=>i.groupKey===key && i.status!=="restored").sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  const mine=db.reports.filter(r=>r.userId===user.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  // When a resident's own report has had no neighbour confirmations after 5 minutes,
  // create a one-time in-app prompt to complete the household check.
  for (const incident of active) {
    const ownReport=db.reports.find(r=>r.incidentId===incident.id && r.userId===user.id && r.kind==="outage");
    const ageMs=Date.now()-new Date(incident.createdAt).getTime();
    if (ownReport && incident.confirmationCount===0 && ageMs>=5*60*1000 && !incident.followUpSentAt) {
      incident.followUpSentAt=now();
      notify(db,user.id,"No neighbour response yet","Please complete the house-level check. You can still lodge an official complaint if the cause is unclear.",incident.id);
    }
  }
  writeDB(db);
  const notifications=db.notifications.filter(n=>n.userId===user.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  res.json({user:cleanUser(user),activeIncidents:active, myReports:mine, notifications, incidentHistory:db.incidents.filter(i=>i.groupKey===key).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,20)});
});
app.post("/api/incidents/report",requireAuth,(req,res)=>{
  const db=readDB(), user=currentUser(db,req);
  if(user.role!=="resident") return res.status(403).json({error:"Resident account required."});
  const existing=db.incidents.find(i=>i.groupKey===incidentKey(user)&&i.status!=="restored"&&Date.now()-new Date(i.createdAt).getTime()<24*60*60*1000);
  let incident=existing;
  if(!incident){
    incident={id:id("inc"),groupKey:incidentKey(user),locality:user.locality,areaLabel:user.housingType==="apartment"?`${user.apartment}, Block ${user.block}`:`${user.locality}, ${user.street}`,status:"reported",createdAt:now(),restoredAt:null,complaintReference:"",officialStatus:"Not submitted",reportsCount:0,confirmationCount:0,followUpSentAt:null,restorationConfirmedBy:[]};
    db.incidents.push(incident);
    notifyNeighbors(db,user,incident);
  }
  const already=db.reports.find(r=>r.incidentId===incident.id&&r.userId===user.id);
  if(!already){db.reports.push({id:id("rep"),incidentId:incident.id,userId:user.id,kind:"outage",createdAt:now(),affected:true,checklist:null});incident.reportsCount++;}
  writeDB(db);
  res.json({incident,joinedExisting:!!existing,message:existing?"Added your report to the existing incident.":"Incident created; nearby residents have been notified."});
});
app.post("/api/incidents/:id/confirm",requireAuth,(req,res)=>{
  const db=readDB(), user=currentUser(db,req), incident=db.incidents.find(i=>i.id===req.params.id);
  if(!incident)return res.status(404).json({error:"Incident not found."});
  const {affected}=req.body||{};
  if(typeof affected!=="boolean")return res.status(400).json({error:"Choose whether you are affected."});
  let report=db.reports.find(r=>r.incidentId===incident.id&&r.userId===user.id);
  if(!report){report={id:id("rep"),incidentId:incident.id,userId:user.id,kind:"neighbor_response",createdAt:now(),affected,checklist:null};db.reports.push(report);}
  else {report.affected=affected;report.respondedAt=now();}
  incident.confirmationCount=db.reports.filter(r=>r.incidentId===incident.id&&r.affected).length;
  if(incident.confirmationCount>=2 && incident.status==="reported") incident.status="community_confirmed";
  notify(db,incident.reports[0]?.userId,"Neighbour response received",`${user.name} responded: ${affected?"also affected":"not affected"}.`,incident.id);
  writeDB(db);res.json({ok:true,incident});
});
app.post("/api/incidents/:id/home-check",requireAuth,(req,res)=>{
  const db=readDB(), user=currentUser(db,req), incident=db.incidents.find(i=>i.id===req.params.id);
  if(!incident)return res.status(404).json({error:"Incident not found."});
  const {nearbyOut,breakerTripped,hazard,notes}=req.body||{};
  const report=db.reports.find(r=>r.incidentId===incident.id&&r.userId===user.id);
  if(report) report.checklist={nearbyOut:!!nearbyOut,breakerTripped:!!breakerTripped,hazard:!!hazard,notes:notes||"",checkedAt:now()};
  if(hazard) notify(db,incident.reports[0]?.userId||user.id,"Electrical safety warning","Do not touch wiring or electrical equipment. Contact the utility or a qualified electrician.",incident.id);
  writeDB(db);res.json({ok:true,interpretation:hazard?"Safety concern: avoid touching equipment and seek qualified help.":breakerTripped?"A household breaker may be involved; do not open panels or handle wiring.":nearbyOut?"Nearby outage reported: consider escalating to the utility.":"No clear cause identified. You may still lodge an official complaint."});
});
app.post("/api/incidents/:id/complaint",(req,res)=>{
  if(!req.session.userId)return res.status(401).json({error:"Please log in."});
  const db=readDB(),user=currentUser(db,req),incident=db.incidents.find(i=>i.id===req.params.id);
  if(!incident)return res.status(404).json({error:"Incident not found."});
  const {reference,provider,notes}=req.body||{};
  incident.complaintReference=reference||"Pending / not provided";
  incident.provider=provider||"Not specified";
  incident.officialStatus="Complaint recorded by app handler";
  incident.status="complaint_lodged";
  incident.complaintUpdatedAt=now();
  db.complaintLog.push({id:id("cmp"),incidentId:incident.id,enteredBy:user.id,reference:incident.complaintReference,provider:incident.provider,notes:notes||"",createdAt:now()});
  db.users.filter(u=>u.role==="resident"&&incidentKey(u)===incident.groupKey).forEach(u=>notify(db,u.id,"Complaint update",`Complaint recorded: ${incident.complaintReference}`,incident.id));
  writeDB(db);res.json({ok:true,incident});
});
app.post("/api/incidents/:id/restore",(req,res)=>{
  if(!req.session.userId)return res.status(401).json({error:"Please log in."});
  const db=readDB(),user=currentUser(db,req),incident=db.incidents.find(i=>i.id===req.params.id);
  if(!incident)return res.status(404).json({error:"Incident not found."});
  const {confirmed}=req.body||{};
  if(!confirmed)return res.status(400).json({error:"Confirm that power has returned."});
  if(!incident.restorationConfirmedBy.includes(user.id))incident.restorationConfirmedBy.push(user.id);
  // A resident can report restoration; admin can finalize it. Never imply utility-verified status.
  incident.restorationReportedAt=now();
  if(user.role==="admin" || incident.restorationConfirmedBy.length>=2){incident.status="restored";incident.restoredAt=now();}
  else incident.status="restoration_reported";
  db.users.filter(u=>u.role==="resident"&&incidentKey(u)===incident.groupKey).forEach(u=>notify(db,u.id,"Restoration update",user.role==="admin"?"Handler marked the incident restored.":"A resident reported power restoration. Confirm if your power is back.",incident.id));
  writeDB(db);res.json({ok:true,incident});
});

app.get("/api/admin/overview",requireAuth,(req,res)=>{
  const db=readDB(),user=currentUser(db,req);if(user.role!=="admin")return res.status(403).json({error:"Admin account required."});
  res.json({incidents:db.incidents.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),reports:db.reports,users:db.users.filter(u=>u.role==="resident").map(cleanUser),complaints:db.complaintLog});
});
app.post("/api/admin/incidents/:id/status",requireAuth,(req,res)=>{
  const db=readDB(),user=currentUser(db,req);if(user.role!=="admin")return res.status(403).json({error:"Admin account required."});
  const incident=db.incidents.find(i=>i.id===req.params.id);if(!incident)return res.status(404).json({error:"Incident not found."});
  const {status,notes}=req.body||{};const allowed=["reported","community_confirmed","complaint_lodged","restoration_reported","restored","closed"];
  if(!allowed.includes(status))return res.status(400).json({error:"Invalid status."});
  incident.status=status;incident.adminNotes=notes||"";incident.updatedAt=now();
  if(status==="restored"||status==="closed"){incident.restoredAt=incident.restoredAt||now();}
  db.statusUpdates.push({id:id("upd"),incidentId:incident.id,adminId:user.id,status,notes:notes||"",createdAt:now()});
  db.users.filter(u=>u.role==="resident"&&incidentKey(u)===incident.groupKey).forEach(u=>notify(db,u.id,"Incident status updated",`Status: ${status.replaceAll("_"," ")}`,incident.id));
  writeDB(db);res.json({incident});
});
app.post("/api/notifications/read",requireAuth,(req,res)=>{
  const db=readDB();db.notifications.filter(n=>n.userId===req.session.userId).forEach(n=>n.read=true);writeDB(db);res.json({ok:true});
});

app.use(express.static(PUBLIC_DIR));
app.get("*",(req,res)=>res.sendFile(path.join(PUBLIC_DIR,"index.html")));
app.listen(PORT,()=>console.log(`BijliMitra running at http://localhost:${PORT}`));
