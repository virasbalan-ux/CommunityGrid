# BijliMitra MVP (local prototype)

A simple mobile-friendly web app with an Express backend and JSON-file persistence. It demonstrates:
- Resident and handler/admin logins
- Resident profile setup (apartment/block/flat or independent house/locality/street)
- Seeded demo accounts so you can test two residents in the same group
- Outage reporting and grouping by apartment+block or locality+street
- In-app neighbour alerts (dashboard polling every 8 seconds)
- Neighbour affected/not-affected response
- House-level safety checklist after an uncertain report
- Admin records utility/provider and complaint reference; admin updates incident status
- Residents report restoration; two resident confirmations or admin confirmation finalize restoration
- Incident history and calculated outage duration

## Run in VS Code
1. Install Node.js (LTS).
2. Extract this ZIP and open the `bijlimitra-mvp` folder in VS Code.
3. Open Terminal in that folder and run:
   ```bash
   npm install
   npm start
   ```
4. Open http://localhost:3000

## Demo accounts
- Resident 1: `asha` / `demo123`
- Neighbor in same apartment block: `rahul` / `demo123`
- Independent-house residents: `meera` / `demo123`, `dev` / `demo123`
- Handler/admin: `admin` / `admin123`

Suggested test:
1. Log in as `asha` in one browser window and report an outage.
2. Open a private/incognito window, log in as `rahul`, and view the dashboard. A neighbour notification should appear (polling may take up to 8 seconds).
3. Confirm affected as Rahul.
4. Log in as `admin` and record a mock utility complaint reference, then update incident status.
5. Return to resident and report restoration. The admin can finalize restoration, or a second resident restoration confirmation does so.

## Temporary data
Data is stored in `data/db.json`. It is created automatically on first run. Stop the server and delete `data/db.json` to reset to the seeded demo data. Do not edit it while the server is running.

## Prototype limitations / before real deployment
- This is a local demonstration, not production-ready. JSON file storage is suitable for a single-user/local prototype only; simultaneous writes, backups, access control, and scaling need a real database.
- The app does not contact BESCOM or another utility automatically. The handler uses the provider's official channel and records the complaint reference/status.
- Notifications are in-app only and require the app to be open; no push/SMS/WhatsApp integration yet.
- The 5–10 minute follow-up is represented by a user-accessible home-check panel for the MVP. A production version should implement server-side scheduled jobs and push notifications. Browser polling cannot reliably run when the app is closed.
- Demo credentials are for testing only. Change the session secret and use HTTPS, secure cookies, rate limiting, validation, privacy controls, and a database before deployment.
- House number is collected for profile setup but is not shown in public incident area labels. Do not expose exact addresses or coordinates to other residents.
- Incident grouping uses apartment+block or locality+street, not electrical feeder topology. Nearby homes may be connected to different feeders.
